// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.


 chrome.storage.sync.get({followednames:'[]'}, function(items) {
	  followednames=items.followednames;
	  if(followednames!='[]')
	  {
		  chrome.storage.local.set({followednames:followednames}, function() {});
		  chrome.storage.sync.set({followednames:'[]'}, function() {});
	  }
	  
  });	
function converttomilli(dur,type)
{
    if (type=='sec')
        dur=dur*1000
    else if (type=='min')
        dur=dur*60*1000
    else if (type=='hr')
        dur=dur*60*60*1000
    else if (type=='day')
        dur=dur*24*60*60*1000    
    
    return dur;
    
}
setdatecount()    
var toolsforusshow
function settoolsforusshow(htmldata){
	             chrome.storage.local.set({toolsforusshow:htmldata}, function() {});  
}
chrome.storage.local.get({toolsforusshow: ""}, function(data) {
	if(typeof data.toolsforusshow === 'undefined' || data.toolsforusshow=='')
	{
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			   // Typical action to be performed when the document is ready:
			   settoolsforusshow(settoolsforusshow(xhttp.responseText))
			}
		};
		xhttp.open("GET", "https://temporary.media/toolsforus/twitter.php", true);
		xhttp.send();		
	}
	else{
		document.getElementById('showhtml').innerHTML=data.toolsforusshow;
	}
	});

function setdatecount(){
var today = new Date();
var dd = today.getDate(); 
chrome.storage.local.get('twitter_follower_date', function(data) {
if (typeof data.twitter_follower_date === 'undefined' || data.twitter_follower_date!=dd ) {
             chrome.storage.local.set({
                    twitter_follower_date: dd,
                        unfollowcount:0,
                        followcount:0,
                        likescount:0,
                        retweetscount:0,
						toolsforusshow:''
                }, function() {});                
        } else {
            console.log(data.twitter_follower_date)
            }
        });
    
}

retrievepopup();/////
var reload='setTimeout(function(){ location.reload();}, 1000)';
function click(e) {

	
var duration = document.getElementById("duration").value;
var ele = document.getElementById("type");
var time_type = ele.options[ele.selectedIndex].value;  
var interval='var interval='+converttomilli(duration,time_type)+';';    

var duration2 = document.getElementById("duration2").value;
var ele2 = document.getElementById("type2");
var time_type2 = ele2.options[ele2.selectedIndex].value;  
var interval2='var interval2='+converttomilli(duration2,time_type2)+';';  
var followrate='var followrate='+document.getElementById("clicks").value+';';  
var procount=' var procount=50;'
var execode= interval+interval2+followrate+procount;
    if(e.target.id!='stop')
    {
		savepopup();
		try{	
        chrome.tabs.executeScript(null,
        {file: 'toast.js'});
          chrome.tabs.executeScript({
          code: execode
        }); 
	
			chrome.tabs.executeScript(null,{file:  e.target.id + '.js'});
		}
		catch(e){}
    }
    else
    {
		        
		chrome.tabs.executeScript({
          code: reload
        });
      //  chrome.extension.sendMessage({ cmd: "protab"});
	//	chrome.extension.sendMessage({ cmd: "alert" ,msg:'Please buy pro version and support us, It has lot more features'});
         
    }   
  window.close();
}


document.addEventListener('DOMContentLoaded', function () {
  var divs = document.querySelectorAll('div');
  for (var i = 0; i < divs.length; i++) {
    divs[i].addEventListener('click', click);
  }
});



function savepopup(){

var ele = document.getElementById("type");
var ele2 = document.getElementById("type2");   
  chrome.storage.local.set({ 
  popup_min     : document.getElementById("duration").value,
  popup_min_type:ele.options[ele.selectedIndex].value,
  popup_max     :document.getElementById("duration2").value,
  popup_max_type:ele2.options[ele2.selectedIndex].value,
  popup_follow_rate:document.getElementById("clicks").value
  }, function() {
    if (chrome.runtime.error) {
      console.log("Runtime error.");
    }
  });  
    
}
function retrievepopup(){
 chrome.storage.local.get({
    popup_min: 3,
    popup_min_type: "sec",
    popup_max: 3,
    popup_max_type: "sec",
    popup_follow_rate:3
     }, function(items) {
   document.getElementById("duration").value=items.popup_min;
   document.getElementById("duration2").value=items.popup_max;
   document.getElementById("clicks").value=items.popup_follow_rate;
   popupSelectindex("type",items.popup_min_type) 
   popupSelectindex("type2",items.popup_max_type) 
   
    });
}



function popupSelectindex(id,val) {
    var sel = document.getElementById(id);

    for(var i = 0, j = sel.options.length; i < j; ++i) {
        console.log(sel.options[i].value)
        if(sel.options[i].value === val) {
           sel.selectedIndex = i;
           break;
        }
    }
}

// /**
 // * Add your Analytics tracking ID here.
 // */
// var _AnalyticsCode = 'UA-120671952-3';
// /**
 // * Below is a modified version of the Google Analytics asynchronous tracking
 // * code snippet.  It has been modified to pull the HTTPS version of ga.js
 // * instead of the default HTTP version.  It is recommended that you use this
 // * snippet instead of the standard tracking snippet provided when setting up
 // * a Google Analytics account.
 // */
// var _gaq = _gaq || [];
// _gaq.push(['_setAccount', _AnalyticsCode]);
// _gaq.push(['_trackPageview']);
// (function() {
  // var ga = document.createElement('script');
  // ga.type = 'text/javascript';
  // ga.async = true;
  // ga.src = 'https://ssl.google-analytics.com/ga.js';
  // var s = document.getElementsByTagName('script')[0];
  // s.parentNode.insertBefore(ga, s);
// })();
// /**
 // * Track a click on a button using the asynchronous tracking API.
 // *
 // * See http://code.google.com/apis/analytics/docs/tracking/asyncTracking.html
 // * for information on how to use the asynchronous tracking API.
 // */
// function trackButtonClick(e) {
  // _gaq.push(['_trackEvent', e.target.id, 'clicked']);
// }
// /**
 // * Now set up your event handlers for the popup's `button` elements once the
 // * popup's DOM has loaded.
 // */
// document.addEventListener('DOMContentLoaded', function () {
  // var buttons = document.querySelectorAll('button');
  // for (var i = 0; i < buttons.length; i++) {
    // buttons[i].addEventListener('click', trackButtonClick);
  // }
// });