
chrome.extension.sendMessage({ cmd: "tutorial"});