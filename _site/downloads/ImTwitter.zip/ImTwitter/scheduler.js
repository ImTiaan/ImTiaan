document.getElementById('schedulerl').click()//////////
var reload='setTimeout(function(){ location.reload();}, 1000)';
/* function clickbutton(e) {

	
var duration = 3;

var time_type = 'sec';
var interval='var interval='+converttomilli(duration,time_type)+';';    

var duration2 = 3;

var time_type2 ='sec';  
var interval2='var interval2='+converttomilli(duration2,time_type2)+';';  
var followrate='var followrate=3;';  
var schedulecountstr='var schedulecountval='+obj.schedulecount+';';

var procount=' var procount=20;'
var execode= interval+interval2+followrate+procount;
alert('starting')
  	try{	
	chrome.tabs.create({url: "https://twitter.com/msdev/following", active: false},function(tab,info){
  setTimeout(function(){
{
        chrome.tabs.executeScript(tab.id,{file: 'toast.js'});
          chrome.tabs.executeScript(tab.id,{code: execode}); 	
			chrome.tabs.executeScript(tab.id,{file:  e.target.getAttribute('action') + '.js'});	
		}  }, 5000);
	
	});

		}
		catch(e){alert(e)}  
  
}*/


document.addEventListener('DOMContentLoaded', function () {
/*    var divs = document.querySelectorAll('.schedulertest');
  for (var i = 0; i < divs.length; i++) {
    divs[i].addEventListener('click', clickbutton);
  }   */
    
  document.getElementById('scheduleradd').addEventListener('click', scheduleraddrow)
  document.getElementById('schedulersave').addEventListener('click', saveschedule)
  getobject()
});

function scheduleraddrow(){
	var str='<tr id="'+(Math.random()*1e32).toString(36)+'" class="schedulerows" ><td><input  class="schedulecheckbox"  type="checkbox"></td>  <td> <select style="" title="Select the Unit"   class="scheduletype">      <option style="font-size: 1em;color:black;"value="autofollow">Follow</option>      <option style="font-size: 1em;color:black;" value="autounfollow">Unfollow</option>      <option style="font-size: 1em;color:black;"value="autolike">Like</option>      <option style="font-size: 1em;color:black;"value="autoremovelike">Unlike</option>	  <option style="font-size: 1em;color:black;"value="retweet">Retweet</option>	  <option style="font-size: 1em;color:black;"value="removeretweet">Unretweet</option>    </select></td><td><input class="schedulecount"value=15></td>	<td><input class="schedulerate"value=3></td> <td><input class="schedulemin"value=3></td> <td><input class="schedulemax"value=3></td> <td><select style="" title="Select the Unit"   class="scheduledurationtype">      <option style="font-size: 1em;color:black;"value="sec">Sec</option>      <option style="font-size: 1em;color:black;" value="min">Min</option>      <option style="font-size: 1em;color:black;"value="hr">Hr</option>      <option style="font-size: 1em;color:black;"value="day">Day</option>    </select></td> <td><input class="scheduletimehr"value=18></td> <td><input class="scheduletimemin"value=53></td> <td><input class="scheduleurl"value="https://twitter.com/msdev/following"></td> <td><button class="schedulerremove" >X</button></td> </tr>';
	var rowele=createElement( str,'table' )
	  var div2 = rowele.querySelectorAll('.schedulerremove');
	  for (var i = 0; i < div2.length; i++) {
		div2[i].addEventListener('click', schedulerremovefunc);
	  }	 	
	document.getElementById('schedulertable').appendChild(rowele)
	saveschedule()

		 

	
}

function converttomilli(dur,type)
{
    if (type=='sec')
        dur=dur*1000
    else if (type=='min')
        dur=dur*60*1000
    else if (type=='hr')
        dur=dur*60*60*1000
    else if (type=='day')
        dur=dur*24*60*60*1000    
    
    return dur;
    
}

function createElement( str,tag='div' ) {
    var frag = document.createDocumentFragment();

    var elem = document.createElement(tag);
    elem.innerHTML = str;

    while (elem.childNodes[0]) {
        frag.appendChild(elem.childNodes[0]);
    }
    return frag;
}

function saveschedule(){
var list= document.getElementsByClassName('schedulerows');
var tableobj={}
for (index in list){
	if(!isNaN(index)){
	var ele=list[index].getElementsByClassName('scheduledurationtype')[0]
	var time_type = ele.options[ele.selectedIndex].value;
	ele2=list[index].getElementsByClassName('scheduletype')[0]
	var schedule_type = ele2.options[ele2.selectedIndex].value;
	var min  = list[index].getElementsByClassName("schedulemin")[0].value;
	var max  = list[index].getElementsByClassName("schedulemax")[0].value;
	var url  = list[index].getElementsByClassName("scheduleurl")[0].value;
	var rate = list[index].getElementsByClassName("schedulerate")[0].value;
	var hr   = list[index].getElementsByClassName("scheduletimehr")[0].value;
	var mins = list[index].getElementsByClassName("scheduletimemin")[0].value;
	var schedulecount = list[index].getElementsByClassName("schedulecount")[0].value;
	var schcheckbox = list[index].getElementsByClassName("schedulecheckbox")[0].checked;
	
	tableobj[list[index].id]={"schedulecount":schedulecount,"rate":rate,"time_type":time_type,"schedule_type":schedule_type,"min":min,"max":max,"url":url,"hr":hr,"mins":mins,"schcheckbox":schcheckbox}
	console.log(tableobj)}
	  chrome.storage.local.set({tableobj: tableobj}, function() {});
	   chrome.storage.local.set({scheduleeveryday: document.getElementsByClassName("scheduleeveryday")[0].checked}, function() {});
      
}	
getobject()	
}
	
	
function getobject(){
	chrome.storage.local.get({scheduleeveryday:false}, function(result) {
		document.getElementsByClassName("scheduleeveryday")[0].checked=result.scheduleeveryday;
	});
       chrome.storage.local.get({tableobj:'none'}, function(result) {
			console.log(result.tableobj)
	   if(result.tableobj=='none')
			console.log('none')
		else
			objecttohtml(result.tableobj);
        });
}	
function objecttohtml(table){
var htmlstr=''
	var tableele=document.getElementById('schedulertable')
	tableele.innerHTML='<thead><tr><td></td><td>Action Type</td><td>No. of Actions</td><td>Rate</td><td>Min</td><td>Max</td><td>Duration Type</td><td>HR(24)</td><td>Min</td><td>url</td><td> </td></tr></thead>';
	
    for(var row in table){
		console.log(row)
		console.log(table[row])
        tableele.appendChild(createElement('<tbody><tr id="'+row+'" class="schedulerows" ><td><input  class="schedulecheckbox"  type="checkbox"></td> <td> <select style="" title="Select the Unit"   class="scheduletype">      <option style="font-size: 1em;color:black;"value="autofollow">Follow</option>      <option style="font-size: 1em;color:black;" value="autounfollow">Unfollow</option>      <option style="font-size: 1em;color:black;"value="autolike">Like</option>      <option style="font-size: 1em;color:black;"value="autoremovelike">Unlike</option>	  <option style="font-size: 1em;color:black;"value="retweet">Retweet</option>	  <option style="font-size: 1em;color:black;"value="removeretweet">Unretweet</option>    </select></td><td><input class="schedulecount"value='+table[row].schedulecount+'></td><td><input class="schedulerate"value="'+table[row].rate+'"></td> <td><input class="schedulemin"value='+table[row].min+'></td> <td><input class="schedulemax"value='+table[row].max+'></td> <td><select style="" title="Select the Unit"   class="scheduledurationtype">      <option style="font-size: 1em;color:black;"value="sec">Sec</option>      <option style="font-size: 1em;color:black;" value="min">Min</option>      <option style="font-size: 1em;color:black;"value="hr">Hr</option>      <option style="font-size: 1em;color:black;"value="day">Day</option>    </select></td> <td><input class="scheduletimehr"value='+table[row].hr+'></td> <td><input class="scheduletimemin"value='+table[row].mins+'></td> <td><input class="scheduleurl"value="'+table[row].url+'"></td> <td><button class="schedulerremove" >X</button></td> </tr></tbody>','table'));   
     }
	  var div2 = document.querySelectorAll('.schedulerremove');
	  for (var i = 0; i < div2.length; i++) {
		div2[i].addEventListener('click', schedulerremovefunc);
	  }	 
	 for(var row in table){
		console.log(table[row])
		popupSelectindex(row,'scheduletype',table[row].schedule_type) 
		popupSelectindex(row,'scheduledurationtype',table[row].time_type) 
		document.getElementById(row).getElementsByClassName('schedulecheckbox')[0].checked=table[row].schcheckbox
	 }
		 
	 
}	

function schedulerremovefunc(e){
	var deletebutton=e.target;
	deletebutton.parentElement.parentElement.parentElement.remove()
	saveschedule()
//	getobject()
}


function popupSelectindex(id,cls,val) {
    var sel = document.getElementById(id).getElementsByClassName(cls)[0];

    for(var i = 0, j = sel.options.length; i < j; ++i) {
        console.log(sel.options[i].value)
        if(sel.options[i].value === val) {
           sel.selectedIndex = i;
           break;
        }
    }
}


function ShowLocalDate(h,m){
    var dNow = new Date();
    var localdate= new Date();
	var scheduleddate=new Date(dNow.getFullYear(), dNow.getMonth(), dNow.getDate(), h, m, 0);
	
	console.log(localdate)
	console.log(scheduleddate)
	return(localdate>scheduleddate);
    
}

function getlatestschedule(){
chrome.storage.local.get({tableobj:'none'}, function(result) {
	var table=result.tableobj
	if(table!='none')
	{
		   for(var row in table){
			   var tr=document.getElementById(row)
				   if(!table[row].schcheckbox)
				   {
					   var istime=ShowLocalDate(table[row].hr,table[row].mins)
					    console.log(table[row].hr)
						console.log(istime)
						if (istime)
						{
							console.log('yes');
							tr.getElementsByClassName('schedulecheckbox')[0].checked=true
							table[row].schcheckbox=true
							callfunction(table[row])
							saveschedule();
							//getobject();
							break;
						}
				   }
		   }
	}
	
});	
}

function callfunction(obj){
	
var duration = obj.min;
var duration2 = obj.max;

var time_type = obj.time_type;
var interval='var interval='+converttomilli(duration,time_type)+';';    
var interval2='var interval2='+converttomilli(duration2,time_type)+';';  
var followrate='var followrate='+obj.rate+';';
var schedulecountstr='var schlcntv='+obj.schedulecount+';';

var procount=' var procount=20;'
var closewindow=' setTimeout(function(){ window.close() }, 500000);';
var execode= interval+interval2+followrate+procount+schedulecountstr+closewindow;
//alert(execode)
 	try{	
	chrome.tabs.create({url: obj.url, active: false},function(tab,info){
  setTimeout(function(){{
        chrome.tabs.executeScript(tab.id,{file: 'toast.js'});
          chrome.tabs.executeScript(tab.id,{code: execode}); 	
			chrome.tabs.executeScript(tab.id,{file: obj.schedule_type + '.js'});	
		}  }, 5000);
	
	});

		}
		catch(e){alert(e)}  


}



function runinbg(){
	try{getlatestschedule()}catch(e){}
	setTimeout(function(){ runinbg(); }, 600000);
}