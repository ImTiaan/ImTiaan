function hexColorDelta(hex1, hex2) {
    // get red/green/blue int values of hex1
    var r1 = parseInt(hex1.substring(0, 2), 16);
    var g1 = parseInt(hex1.substring(2, 4), 16);
    var b1 = parseInt(hex1.substring(4, 6), 16);
    // get red/green/blue int values of hex2
    var r2 = parseInt(hex2.substring(0, 2), 16);
    var g2 = parseInt(hex2.substring(2, 4), 16);
    var b2 = parseInt(hex2.substring(4, 6), 16);
    // calculate differences between reds, greens and blues
    var r = 255 - Math.abs(r1 - r2);
    var g = 255 - Math.abs(g1 - g2);
    var b = 255 - Math.abs(b1 - b2);
    // limit differences between 0 and 1
    r /= 255;
    g /= 255;
    b /= 255;
    // 0 means opposit colors, 1 means same colors
    return (r + g + b) / 3;
}

function componentToHex(c) {
    c=parseInt(c)
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
}

function rgbToHex(rgb) {
    rgb = rgb.substring(4, rgb.length-1)
         .replace(/ /g, '')
         .split(',');

    return "#" + componentToHex(rgb[0]) + componentToHex(rgb[1]) + componentToHex(rgb[2]);
}

function randomIntFromInterval(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

 function removeretweet(spans,i)
{ 
try{
    
    var randominterval=randomIntFromInterval(interval,interval2)
    console.log(randominterval)
    var span_tag = spans[i];
    var font_col=rgbToHex(window.getComputedStyle(span_tag, null).getPropertyValue("color"))
    var delta_col=hexColorDelta('657786',font_col.replace('#',''))
    //console.log(hexColorDelta('17bf63',font_col.replace('#','')))
    //console.log(delta_col)
    if (delta_col<.9)
    {   
        span_tag.parentElement.classList.add("in");
		schedulecountmax();
		countmax();
		span_tag.parentElement.parentElement.scrollIntoView();
        span_tag.parentElement.parentElement.click()
       // setTimeout(function(){document.querySelectorAll('button.EdgeButton.EdgeButton--primary.retweet-action')[0].click();}, 2000);
        return   setTimeout(function(){removeretweet(spans,i+2);}, randominterval);
    }
    else if (delta_col>.9)
        return removeretweet(spans,i+2);
    else
        return   setTimeout(function(){removeretweet(spans,i+2);}, randominterval);
}
catch (e) {
runremoveretweet()
}    
}
    
function runremoveretweet()
{
    var tweet_interval=interval
    var spans = document.querySelectorAll('span.Icon--retweet')
    var i=0;
    removeretweet(spans,i);
    window.scrollBy(0,document.body.scrollHeight);
}
 runremoveretweet()
 
 var counter=0
var runonce=true
function countmax(){
	counter=counter+1;
	if(counter>procount)
	{
		if(runonce){
			runonce=false
			chrome.extension.sendMessage({ cmd: "alert" ,msg:'Please buy pro version and support us, It has lot more features'});
			chrome.extension.sendMessage({ cmd: "protab"});
		}
        location.reload();
	}
}

var schedulecounter=0
var schedulerunonce=true
function schedulecountmax(){
	try{
	console.log('schedulecountval=='+schlcntv)
	console.log('procount=='+procount)
	
	schedulecounter=schedulecounter+1;
/* 	if (typeof schlcntv === 'undefined') {
		var schlcntv=1000
	} */
	console.log(schedulecounter+' > '+schlcntv)
	if(schedulecounter>schlcntv)
	{
		window.close(); 
	}}
	catch(e){}
}