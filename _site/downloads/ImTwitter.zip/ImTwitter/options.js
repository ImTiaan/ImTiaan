setdatecount()    

function setdatecount(){
var today = new Date();
var dd = today.getDate(); 
chrome.storage.local.get('twitter_follower_date', function(data) {
if (typeof data.twitter_follower_date === 'undefined' || data.twitter_follower_date!=dd ) {
             chrome.storage.local.set({
                    twitter_follower_date: dd,
                        unfollowcount:0,
                        followcount:0,
                        likescount:0,
                        retweetscount:0
                }, function() {});                
        } else {
            console.log(data.twitter_follower_date)
            }
        });
    
}
function openCity(evt) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace("active", "");
    }
    document.getElementById(evt.currentTarget.id.slice(0, -1)).style.display = "block";
	//evt.currentTarget.className += " active";
	document.getElementById(evt.currentTarget.id).className += " active";

}

// Get the element with id="defaultOpen" and click on it


  var buttons2 = document.querySelectorAll('.tablinks');
  for (var i = 0; i < buttons2.length; i++) {
	 
    buttons2[i].addEventListener('click', openCity);
	  buttons2[0].click();
  }

function writeconsole(event){
console.log(event.currentTarget.textContent)
}

function disable_enable_unfollow(value) {
   console.log(value)
 /*     var eles=document.getElementsByTagName('select');
    for (var j = 0; j < eles.length; j++) {
        eles[j].disabled =value
    } */
    var eles=document.getElementsByClassName('advancedinputunfollow');
    for (var j = 0; j < eles.length; j++) {
        eles[j].disabled =value
    }
}
//document.getElementById('opfeatures').disabled = !document.getElementById('useoptions').checked; 
function disable_enable(value) {
  console.log(value)
  /*     var eles=document.getElementsByTagName('select');
    for (var j = 0; j < eles.length; j++) {
        eles[j].disabled =value
    } */
    var eles=document.getElementsByClassName('advancedinput');
    for (var j = 0; j < eles.length; j++) {
        eles[j].disabled =value
    }
}
function addcontainslistner(ele){
    var selectedvalue=document.getElementById(ele).value
    if (selectedvalue.indexOf('contain') !== -1)
         document.getElementById(ele+"input").style.display = 'block';
    else
         document.getElementById(ele+"input").style.display = 'none';    
    document.getElementById(ele).onchange = function(){
    var selectedvalue=document.getElementById(ele).value
    if (selectedvalue.indexOf('contain') !== -1)
         document.getElementById(ele+"input").style.display = 'block';
    else
         document.getElementById(ele+"input").style.display = 'none';
};
}
function addcontainslistnerunfollow(ele){
    var selectedvalue=document.getElementById(ele+"unfollow").value
    if (selectedvalue.indexOf('contain') !== -1)
         document.getElementById(ele+"unfollow"+"input").style.display = 'block';
    else
         document.getElementById(ele+"unfollow"+"input").style.display = 'none';    
    document.getElementById(ele+"unfollow").onchange = function(){
    var selectedvalue=document.getElementById(ele+"unfollow").value
    if (selectedvalue.indexOf('contain') !== -1)
         document.getElementById(ele+"unfollow"+"input").style.display = 'block';
    else
         document.getElementById(ele+"unfollow"+"input").style.display = 'none';
};
}

document.getElementById('useoptions').onchange = function(){disable_enable(!document.getElementById('useoptions').checked)};
document.getElementById('useoptionsunfollow').onchange = function(){disable_enable_unfollow(!document.getElementById('useoptionsunfollow').checked)};

// Saves options to chrome.storage
function save_options() {
  var loc = document.getElementById('loc').value;
  var bio = document.getElementById('bio').value;
  var url = document.getElementById('url').value;
  var img = document.getElementById('img').value;
  var skipproaccount = document.getElementById('skipproaccount').checked;
  var skipwhotofollow = document.getElementById('skipwhotofollow').checked;
  var beepwhennone = document.getElementById('beepwhennone').checked;
  
  
  var followlimit=document.getElementById('followlimit').value;
  var unfollowlimit=document.getElementById('unfollowlimit').value;
  
  var likeslimit=document.getElementById('likeslimit').value;
  var retweetslimit=document.getElementById('retweetslimit').value;
  
  var nonfollows = document.getElementById('nonfollows').checked;
  var skipverified=document.getElementById('skipverified').checked;
  var skipyoungfollows=document.getElementById('skipyoungfollows').checked;
  
  var locinput = document.getElementById('locinput').value; 
  var urlinput = document.getElementById('urlinput').value; 
  var bioinput = document.getElementById('bioinput').value; 
  var useoptions = document.getElementById('useoptions').checked;
  var removeimages = document.getElementById('removeimages').checked;
  
  var locunfollow = document.getElementById('locunfollow').value;
  var biounfollow = document.getElementById('biounfollow').value;
  var urlunfollow = document.getElementById('urlunfollow').value;
  var imgunfollow = document.getElementById('imgunfollow').value;  
  var locunfollowinput = document.getElementById('locunfollowinput').value; 
  var urlunfollowinput = document.getElementById('urlunfollowinput').value; 
  var biounfollowinput = document.getElementById('biounfollowinput').value; 
  var useoptionsunfollow = document.getElementById('useoptionsunfollow').checked;
  var removeimagesunfollow = document.getElementById('removeimagesunfollow').checked;  
  
  chrome.storage.local.set({
    loc: loc,
    url: url,
    bio: bio,
    img: img,    
    locinput: locinput,
    urlinput: urlinput,
    bioinput: bioinput,
    useoptions: useoptions,
    nonfollows: nonfollows,
	skipverified:skipverified,
    skipyoungfollows:skipyoungfollows,
    locunfollow: locunfollow,
    urlunfollow: urlunfollow,
    biounfollow: biounfollow,
    imgunfollow: imgunfollow,    
    locunfollowinput: locunfollowinput,
    urlunfollowinput: urlunfollowinput,
    biounfollowinput: biounfollowinput,
    useoptionsunfollow: useoptionsunfollow,    
    followlimit:followlimit,
    unfollowlimit:unfollowlimit,
    retweetslimit:retweetslimit,
    likeslimit:likeslimit,
    removeimages:removeimages,
    removeimagesunfollow:removeimagesunfollow,
    skipproaccount:skipproaccount,
    skipwhotofollow:skipwhotofollow,
	beepwhennone:beepwhennone
  }, function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.textContent = 'Options saved.';
    var statusunfollow = document.getElementById('statusunfollow');
    statusunfollow.textContent = 'Options saved.';
    var statuslikes = document.getElementById('statuslikes');
    statuslikes.textContent = 'Options saved.';    

    setTimeout(function() {
        disable_enable(!document.getElementById('useoptions').checked);
        disable_enable_unfollow(!document.getElementById('useoptionsunfollow').checked);        

      statusunfollow.textContent = '';
      status.textContent = '';
      statuslikes.textContent = '';
    }, 750);
  });
}
var properties_obj={}
// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default value loc = 'red' and useoptions = true.
  chrome.storage.local.get({
    loc: 'none',
    url: 'none',
    bio: 'none',
    img: 'none',
    locinput: '',
    urlinput: '',
    bioinput: '',    
    useoptions: false,
    removeimages: false,
    skipproaccount:true,
    skipwhotofollow:false,
	beepwhennone:false,
    likeslimit:1000,
    retweetslimit:1000,
    followlimit: 1000,
    followcount:0,
    locunfollow: 'none',
    urlunfollow: 'none',
    biounfollow: 'none',
    imgunfollow: 'none',   
    locunfollowinput: '',
    urlunfollowinput: '',
    biounfollowinput: '',    
    useoptionsunfollow: false,
    removeimagesunfollow: false,   
    nonfollows: false,    
	skipverified:false,
    skipyoungfollows:false,
    unfollowlimit :1000,
    unfollowcount:0,
    retweetscount:0,
    likescount:0
  }, function(items) {
    document.getElementById('loc').value = items.loc;
    document.getElementById('url').value = items.url;
    document.getElementById('bio').value = items.bio;
    document.getElementById('locinput').value = items.locinput;
    document.getElementById('urlinput').value = items.urlinput;
    document.getElementById('bioinput').value = items.bioinput;    
    document.getElementById('img').value = items.img;
    document.getElementById('useoptions').checked = items.useoptions; 
    document.getElementById('removeimages').checked = items.removeimages; 
    document.getElementById('skipproaccount').checked = items.skipproaccount; 
    document.getElementById('skipwhotofollow').checked = items.skipwhotofollow; 
	document.getElementById('beepwhennone').checked = items.beepwhennone; 
    disable_enable(!document.getElementById('useoptions').checked)
    document.getElementById('followcount').innerHTML = items.followcount;
    document.getElementById('unfollowcount').innerHTML = items.unfollowcount;
    document.getElementById('followlimit').value = items.followlimit;
    document.getElementById('unfollowlimit').value = items.unfollowlimit;
    document.getElementById('likeslimit').value = items.likeslimit;
    document.getElementById('retweetslimit').value = items.retweetslimit;
    document.getElementById('likescount').innerHTML = items.likescount;
    document.getElementById('retweetscount').innerHTML = items.retweetscount;
    
    document.getElementById('nonfollows').checked = items.nonfollows; 
	document.getElementById('skipverified').checked = items.skipverified; 
	
    document.getElementById('skipyoungfollows').checked = items.skipyoungfollows; 

    
    document.getElementById('locunfollow').value = items.locunfollow;
    document.getElementById('urlunfollow').value = items.urlunfollow;
    document.getElementById('biounfollow').value = items.biounfollow;
    document.getElementById('locunfollowinput').value = items.locunfollowinput;
    document.getElementById('urlunfollowinput').value = items.urlunfollowinput;
    document.getElementById('biounfollowinput').value = items.biounfollowinput;    
    document.getElementById('imgunfollow').value = items.imgunfollow;
    document.getElementById('useoptionsunfollow').checked = items.useoptionsunfollow; 
    document.getElementById('removeimagesunfollow').checked = items.removeimagesunfollow;     
    disable_enable_unfollow(!document.getElementById('useoptionsunfollow').checked)        
    
    addcontainslistner('loc')
    addcontainslistner('bio')
    addcontainslistner('url')
    addcontainslistnerunfollow('loc')
    addcontainslistnerunfollow('bio')
    addcontainslistnerunfollow('url')    
    
  });
}
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click',save_options);
document.getElementById('saveunfollow').addEventListener('click',save_options);
document.getElementById('savelikes').addEventListener('click',save_options);
setdatecount()    

function setdatecount(){
var today = new Date();
var dd = today.getDate(); 
chrome.storage.local.get('twitter_follower_date', function(data) {
if (typeof data.twitter_follower_date === 'undefined' || data.twitter_follower_date!=dd ) {
             chrome.storage.local.set({
                    twitter_follower_date: dd,
                        unfollowcount:0,
                        followcount:0
                }, function() {});                
        } else {
        //    console.log(data.twitter_follower_date)
            }
        });
    
}
/**
 * Add your Analytics tracking ID here.
 */
var _AnalyticsCode = 'UA-120671952-3';
/**
 * Below is a modified version of the Google Analytics asynchronous tracking
 * code snippet.  It has been modified to pull the HTTPS version of ga.js
 * instead of the default HTTP version.  It is recommended that you use this
 * snippet instead of the standard tracking snippet provided when setting up
 * a Google Analytics account.
 */
var _gaq = _gaq || [];
_gaq.push(['_setAccount', _AnalyticsCode]);
_gaq.push(['_trackPageview']);
(function() {
  var ga = document.createElement('script');
  ga.type = 'text/javascript';
  ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(ga, s);
})();
/**
 * Track a click on a button using the asynchronous tracking API.
 *
 * See http://code.google.com/apis/analytics/docs/tracking/asyncTracking.html
 * for information on how to use the asynchronous tracking API.
 */
function trackButtonClick(e) {
  _gaq.push(['_trackEvent', e.target.id, 'clicked']);
}
/**
 * Now set up your event handlers for the popup's `button` elements once the
 * popup's DOM has loaded.
 */
document.addEventListener('DOMContentLoaded', function () {
  var buttons = document.querySelectorAll('button');
  for (var i = 0; i < buttons.length; i++) {
    buttons[i].addEventListener('click', trackButtonClick);
  }
});

