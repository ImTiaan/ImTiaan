//chrome.tabs.create({ url: chrome.extension.getURL('options.html')});
var optionsurl=chrome.extension.getURL('options.html')

var win = window.open(optionsurl, '_blank');
win.focus();