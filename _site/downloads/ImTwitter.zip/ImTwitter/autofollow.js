var beep = (function () {
    var ctxClass = window.audioContext ||window.AudioContext || window.AudioContext || window.webkitAudioContext
    var ctx = new ctxClass();
    return function (duration, type, finishedCallback) {

        duration = +duration;

        // Only 0-4 are valid types.
        type = (type % 5) || 0;

        if (typeof finishedCallback != "function") {
            finishedCallback = function () {};
        }

        var osc = ctx.createOscillator();

        osc.type = type;
        //osc.type = "sine";

        osc.connect(ctx.destination);
        if (osc.noteOn) osc.noteOn(0); // old browsers
        if (osc.start) osc.start(); // new browsers

        setTimeout(function () {
            if (osc.noteOff) osc.noteOff(0); // old browsers
            if (osc.stop) osc.stop(); // new browsers
            finishedCallback();
        }, duration);

    };
})();

function checkifexists(data,classname){
   try{
    var prop=data.getElementsByClassName(classname)[0].innerText ;
    //console.log(prop)
    if (prop.length>0)
        return true
    else 
        return false;
    }
    catch(err) 
    {return false;}
}

function stripHtml(html){
	 try{
    var temporalDivElement = document.createElement("div");
    temporalDivElement.innerHTML = html;
    var htmltextcontent=temporalDivElement.textContent || temporalDivElement.innerText || "";
    temporalDivElement.remove();
    return htmltextcontent.toLowerCase();
		   }
    catch(err) 
    {return err}
}

function checkbio(myStr,value){
    //console.log('checkbio(myStr)')
    try{
        var profilebio = stripHtml(myStr.match(/<p class="ProfileHeaderCard-bio u-dir" ([\S\s]*?)<\/p>/gmui)[0]).trim()      //.replace('<p class="ProfileHeaderCard-bio u-dir" dir="ltr">','').replace('</p>','')
       // console.log(value[1])
        //console.log(profilebio.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			console.log(patt.test(profilebio))
			return (patt.test(profilebio))	
		}	
		else
			return (profilebio.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profilebio.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}
function checklocation(myStr,value){
    //console.log('checkbio(myStr)')
    try{
         var profilelocation = stripHtml(myStr.match(/<span class="ProfileHeaderCard-locationText u-dir" dir="ltr">([\S\s]*?)<\/span>/gmui)[0]).trim()      //.replace('<span class="ProfileHeaderCard-locationText u-dir" dir="ltr">','').replace('</span>','')
        //console.log(value[1])
        //console.log(profilelocation.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			return (patt.test(profilelocation))	
		}	
		else		
			return (profilelocation.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profilelocation.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}
function checkurlText(myStr,value){
    //console.log('checkbio(myStr)')
    try{
        var profileurlText = stripHtml(myStr.match(/<span class="ProfileHeaderCard-urlText u-dir">([\S\s]*?)<\/span>/gmui)[0]).trim()      //.replace('<span class="ProfileHeaderCard-urlText u-dir" dir="ltr">','').replace('</span>','')
        //console.log(value[1])
        //console.log(profileurlText.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			console.log(patt.test(profileurlText))
			return (patt.test(profileurlText))	
		}	
		else		
			return (profileurlText.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profileurlText.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}
function checkimage(myStr){
    //console.log('checkimage(myStr)')
    try{
        if(imageExists(myStr.match(/<img class="ProfileAvatar-image "([\S\s]*?)>/gmui)[0]))
            return true;
        else
            return false
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}


function imageExists(html){
    var temporalDivElement = document.createElement("div");
    temporalDivElement.innerHTML = html;
    var imgurl=temporalDivElement.childNodes[0].src
    //console.log(imgurl)
    return !(imgurl.indexOf('default_profile_') !== -1) 
}
/* var properties_obj = { bio : true,
                       loc : true,
                       url  : true,
                       img  : true,
                       }; */

var shalluseoptions=false
function executefunction(myStr,functionname,value){
    switch (functionname) {
        case 'bio':
            return checkbio(myStr,value);
            break;
        case 'loc':
            return checklocation(myStr,value);
            break;
        case 'url':
            return checkurlText(myStr,value);
            break;
        case 'img':
            return checkimage(myStr);   
            break;
    }
}

var properties_obj={}
var shalluseoptions
var followcount_twitter,followlimit_twitter,removeimagesvar,skipproaccount,skipwhotofollow,beepwhennone
function getusersettings(username){
  // Use default value loc = 'red' and useoptions = true.
  chrome.storage.local.get({
    loc: 'none',
    url: 'none',
    bio: 'none',
    img: 'none',
    locinput: '',
    urlinput: '',
    bioinput: '',     
    useoptions: false,
    removeimages:false,
    skipproaccount:true,
    skipwhotofollow:false,
	beepwhennone:false,
    unfollowcount: 0,
    followcount: 0,
    followlimit :1000,
    followednames:'[]'
  }, function(items) {
    shalluseoptions=items.useoptions;
    properties_obj = {     bio : [items.bio,items.bioinput],
                           loc : [items.loc,items.locinput],
                           url : [items.url,items.urlinput],
                           img : [items.img,''],
                           };   
    followcount_twitter =parseInt(items.followcount);
    followlimit_twitter =parseInt(items.followlimit);
    unfollowcount_twitter=parseInt(items.unfollowcount);
    //document.getElementById('taffollowed').textContent=followcount_twitter;
    followcount_sub=followcount_twitter;
    removeimagesvar=items.removeimages;
    skipproaccount=items.skipproaccount;
    skipwhotofollow=items.skipwhotofollow;
	beepwhennone=items.beepwhennone;
    followednames=JSON.parse(items.followednames);

    //document.getElementById('tafunfollowed').textContent=unfollowcount_twitter;

    //return checkuser(username)
/*     console.log(properties_obj);
    console.log(shalluseoptions);  */
  });
}

    


function checkuser(username,button){
    var prop_arr=[]
    //console.log(username)
    var isvalid=true;
    if(shalluseoptions==false)
        return true
    
    if(prev_screen_name!=username)
        prev_screen_name=username
    else
    {   
         console.log('prev_screen_name==username')
        button.remove()
        return true
        
    }
    var request = new XMLHttpRequest(); 
    request.open("GET", 'https://twitter.com/'+username);
    request.onreadystatechange = function() { 
        if (request.readyState === 4 && request.status === 200) {
                var myStr = request.responseText;
                Object.keys(properties_obj).forEach(function(key) {
                 //console.log(key, properties_obj[key]);      
                  if(properties_obj[key][0]=='exist')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==true)
                  else if(properties_obj[key][0]=='notexist')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==false)
                  else if(properties_obj[key][0]=='contain')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==true)
                  else if(properties_obj[key][0]=='notcontain')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==false)                
                  else
                  {
                    isvalid =true
                    }
                
                //console.log(isvalid)
                if (isvalid==false)
                {
                    prop_arr.push(0)
                    
                }
                else 
                {
                   prop_arr.push(1)
                    
                }
                if (prop_arr.length==4 && !prop_arr.includes(0))
                { 
                    followcount_twitter=followcount_twitter+1;
                    savefollowcount(followcount_twitter);
                    toast_twitter_follow("green",username)
                    //console.log('this is valid');
					nonetofollow_counter=0;
					schedulecountmax();
					countmax();
                    button.click();
                    followednames.push([username,archdate]);
                    removeclass(button)
                }
                else if (prop_arr.length==4 && prop_arr.includes(0))    
                {  
                    toast_twitter_follow("red",username)
                    //console.log('this is invalid'); 
                    button.remove()
            
            }
                    
                });
            
            
        }
    };
    request.send(null); 
}


//============================follow=============================

function hasClass(element, cls) {
    return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
}

function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

var followednames
var prev_screen_name=''
var firstrun=true
var archd = new Date();
var archdate=archd.getDate()
var nonetofollow_counter=0
function autofollow(interval, interval2) {
	nonetofollow_counter=nonetofollow_counter+1;
	if(beepwhennone && (nonetofollow_counter>5))
	{
	beep(500, 2, function () {
       toast_twitter_follow("red",'Looped '+String(nonetofollow_counter)+' times but couldnt follow anyone, please check if the people to follow are over')
    });
	
	}
	
    chrome.storage.local.set({followednames:JSON.stringify(followednames)}, function() {});
    //console.log(JSON.stringify(followednames));
    //followednames=[];
	try{
    if(firstrun)
    {
        firstrun=false
        removeimages();
    }
    if(followcount_twitter>=followlimit_twitter)
    {
        alert('Follow limit exceeded for the day');
        savefollowcount(followlimit_twitter);
        location.reload();

    } 
    else{
    var randominterval = randomIntFromInterval(interval, interval2)
    scrolldowncount=scrolldowncount+1
    if(scrolldowncount%2==0){
        removeimages();
        if(shalluseoptions)
            window.scrollBy(0, document.body.scrollHeight / 25);
        else
            window.scrollBy(0, document.body.scrollHeight / 10);
    }
    var count_follows = 0;
    var buttons = document.querySelectorAll('button.follow-text')
    //console.log(buttons);
    for (var i = 0; i < buttons.length; i++) {

        //console.log(buttons.length)
        var button = buttons[i];
        var classnames=button.parentElement.parentElement
        var textContent = button.textContent;
        
        //console.log('skipwhotofollow && data-protected')
        //console.log(skipwhotofollow+' '+!button.parentElement.parentElement.hasAttribute('data-protected'))
        if(skipwhotofollow && !button.parentElement.parentElement.hasAttribute('data-protected'))
        {
            button.remove();
            continue;
        } 
       
        
        
        if(skipproaccount && button.parentElement.parentElement.getAttribute('data-protected')=="true")
        {
            button.remove();
            continue;
        }
       
            
                if (hasClass(button.parentElement.parentElement, 'following')) {

                    //console.log('inside following');
                    if (i == (buttons.length - 1))
                        return setTimeout(function() {
                            autofollow(interval, interval2)
                        }, randominterval);
                } else {
                        var screenname=button.parentElement.parentElement.getAttribute('data-screen-name');
                        console.log(screenname)
                        
                        
                        if(shalluseoptions)
                        {
                            
                            setTimeout(function(){ checkuser(screenname,button) }, 200);
                        }
                        else
                        {   
							nonetofollow_counter=0;
							schedulecountmax();
							countmax();
							button.click();
                            followednames.push([button.parentElement.parentElement.getAttribute('data-screen-name'),archdate]);
                            removeclass(button);
                            }
                        //return;                    
                   //// button.click();
                    count_follows = count_follows + 1;
                    if ((followrate <= count_follows) || (i == (buttons.length - 1)))
                    {   
                        if(!shalluseoptions)
                        {
                            followcount_twitter=followcount_twitter+count_follows;
                            savefollowcount(followcount_twitter);
                        }
                        return setTimeout(function() {autofollow(interval, interval2)}, randominterval);}
                }
      /*    */


    }
    if (buttons.length == 0)
        return setTimeout(function() {
            autofollow(interval, interval2)
        }, randominterval);

    }
    }catch(err) 
    {
        //console.log(err)
         return setTimeout(function() {
            autofollow(interval, interval2)
        }, randominterval);
    } 	
}


function removeimages(){
    if(removeimagesvar)
    {
        var images = document.getElementsByTagName('img');
        var l = images.length;
        for (var i = 0; i < l; i++) {
            images[0].parentNode.removeChild(images[0]);
        }    
        var images2 = document.getElementsByClassName("ProfileCard-bg js-nav");
        var l = images2.length;
        for (var i = 0; i < l; i++) {
            images2[0].parentNode.removeChild(images2[0]);
        }   
    }    
}

getusersettings()
var scrolldowncount=0
setTimeout(function(){ 
//console.log(shalluseoptions)
if(shalluseoptions)
{
    if(interval<3000)
        interval=interval+3000;
    if(interval2<3000)
        interval2=interval2+3000;
    followrate=1;
    prev_screen_name='';
    autofollow(interval, interval2);
}
else
   autofollow(interval, interval2);
 }, 2000);



function toast_twitter_follow(bgcolor,screenname){
    
        var options = {
        style: {
            main: {
                //background: "#ee6c6c",
                background: bgcolor,
                color: "black",
                'max-width': '30%',
                'border-radius': '8px',
            }
        },                            
        settings: {
            duration: 1000
        }
    };

    iqwerty.toast.Toast('@'+screenname, options);    
    
}

function savefollowcount(followcount_twitter){
    
    chrome.storage.local.set({followcount:followcount_twitter}, function() {});
    document.getElementById('taffollowed').textContent=followcount_twitter-followcount_sub;
    
}
var followcount_sub
addcountwidget()
function addcountwidget(){  
    var optionsUrl = chrome.extension.getURL("options.html"); 
    var optionstag = '<a href="' + optionsUrl + '" style="font-size: 20px;    color: #14171a;" target="_blank">Options</a>';
    var donationtag = '<a href="https://toolsfor.us/tutorials/index.html?app_name=Twitter_Auto_Follower" style="font-size: 20px;    color: #14171a;" target="_blank">Tips</a>';    
    var p_ele=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 10em;    right: 12em;border-radius: 15px 30px;    background: #3593a0;    padding: 20px;     width: 90px;    height: 65px;" class="rcorners"><table><tr><td align="center">Followed</td></tr><tr><td align="center"><span style="font-size: 35px;font-weight: bold;" id="taffollowed">0</span></td></tr></table></div>')
    var p_ele2=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 10em;    right: 1em;border-radius: 15px 30px;    background: #3593a0;    padding: 20px;     width: 90px;    height: 65px;" class="rcorners2"><table><tr><td align="center">Unfollowed</td></tr><tr><td align="center"><span style="font-size: 35px;font-weight: bold;"id="tafunfollowed">0</span></td></tr></table></div>')
    var p_ele3=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 24em;    right: 4.5em;border-radius: 15px 15px;    background: #3593a0;    padding: 20px;     width: 130px;    height: 20px;" >'+optionstag+'</div>');
    var p_ele4=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 18em;    right: 7em;border-radius: 15px 15px;    background: #ff3a3a;    padding: 20px;     width: 60px;    height: 35px;" >'+donationtag+'</div>')
    document.getElementsByTagName("body")[0].appendChild(p_ele)
    document.getElementsByTagName("body")[0].appendChild(p_ele2)
    document.getElementsByTagName("body")[0].appendChild(p_ele3)
    document.getElementsByTagName("body")[0].appendChild(p_ele4)    
}
function createElement( str ) {
    var frag = document.createDocumentFragment();

    var elem = document.createElement('div');
    elem.innerHTML = str;

    while (elem.childNodes[0]) {
        frag.appendChild(elem.childNodes[0]);
    }
    return frag;
}

function removeclass(element) {
      element.classList.remove("follow-text");
}

var counter=0
var runonce=true
function countmax(){
	counter=counter+1;
	if(counter>procount)
	{
		if(runonce){
			runonce=false
			chrome.extension.sendMessage({ cmd: "alert" ,msg:'Please buy pro version and support us, It has lot more features'});
			chrome.extension.sendMessage({ cmd: "protab"});
		}
        location.reload();
	}
}




var schedulecounter=0
var schedulerunonce=true
function schedulecountmax(){
	try{
	console.log('schedulecountval=='+schlcntv)
	console.log('procount=='+procount)
	
	schedulecounter=schedulecounter+1;
/* 	if (typeof schlcntv === 'undefined') {
		var schlcntv=1000
	} */
	console.log(schedulecounter+' > '+schlcntv)
	if(schedulecounter>schlcntv)
	{
		window.close(); 
	}}
	catch(e){}
}