function findUpTag(el, classname) {
    while (el.parentNode) {
        el = el.parentNode;
        if (el.className.includes(classname))
            return el;
    }
    return [];
}


function checkifexists(data,classname){
   try{
    var prop=data.getElementsByClassName(classname)[0].innerText ;
    //console.log(prop)
    if (prop.length>0)
        return true
    else 
        return false;
    }
    catch(err) 
    {return err;}
}

function stripHtml(html){
    var temporalDivElement = document.createElement("div");
    temporalDivElement.innerHTML = html;
    var htmltextcontent=temporalDivElement.textContent || temporalDivElement.innerText || "";
    temporalDivElement.remove();
    return htmltextcontent.toLowerCase();
}

function checkbio(myStr,value){
    //console.log('checkbio(myStr)')
    try{
        var profilebio = stripHtml(myStr.match(/<p class="ProfileHeaderCard-bio u-dir" ([\S\s]*?)<\/p>/gmui)[0]).trim()      //.replace('<p class="ProfileHeaderCard-bio u-dir" dir="ltr">','').replace('</p>','')
        //console.log(value[1])
        //console.log(profilebio.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			return (patt.test(profilebio))	
		}	
		else		
			return (profilebio.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profilebio.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}
function checklocation(myStr,value){
    //console.log('checkbio(myStr)')
    try{
         var profilelocation = stripHtml(myStr.match(/<span class="ProfileHeaderCard-locationText u-dir" dir="ltr">([\S\s]*?)<\/span>/gmui)[0]).trim()      //.replace('<span class="ProfileHeaderCard-locationText u-dir" dir="ltr">','').replace('</span>','')
        //console.log(value[1])
        console.log(profilelocation.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			return (patt.test(profilelocation))	
		}	
		else		
			return (profilelocation.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profilelocation.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}
function checkurlText(myStr,value){
    //console.log('checkbio(myStr)')
    try{
        var profileurlText = stripHtml(myStr.match(/<span class="ProfileHeaderCard-urlText u-dir">([\S\s]*?)<\/span>/gmui)[0]).trim()      //.replace('<span class="ProfileHeaderCard-urlText u-dir" dir="ltr">','').replace('</span>','')
        //console.log(value[1])
        //console.log(profileurlText.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
		if(value[1].startsWith("/") && value[1].endsWith("/"))
		{
			var patt = new RegExp(value[1].toLowerCase().slice(1, -1));		
			return (patt.test(profileurlText))	
		}	
		else		
			return (profileurlText.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profileurlText.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}

function checkverified(myStr,value){
    //console.log('checkbio(myStr)')
    try{
        var profileurlText = stripHtml(myStr.match(/<span class="ProfileHeaderCard-urlText u-dir">([\S\s]*?)<\/ >/gmui)[0]).trim()      //.replace('<span class="ProfileHeaderCard-urlText u-dir" dir="ltr">','').replace('</span>','')
        //console.log(value[1])
        //console.log(profileurlText.indexOf(value[1])!== -1)
    if (value[0].indexOf('contain') !== -1)
    {
        return (profileurlText.indexOf(value[1].toLowerCase())!== -1)
    }
    else
    {
        if(profileurlText.length>0)
                return true;
            else
                return false
    }
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}

function checkwhetherfollowing(myStr){
    try{
       //if(myStr.indexOf('Send a Direct Message to') !== -1)
        if(myStr.indexOf('ProfileMessagingActions-buttonWrapper u-sizeFull') == -1)           
            return true;
        else
            return false
    }catch(err) 
    {
        console.log(err)
        return false
    }        
    
}
function checkimage(myStr){
    //console.log('checkimage(myStr)')
    try{
        if(imageExists(myStr.match(/<img class="ProfileAvatar-image "([\S\s]*?)>/gmui)[0]))
            return true;
        else
            return false
    }catch(err) 
    {
        console.log(err)
        return false
    }        
}


function imageExists(html){
    var temporalDivElement = document.createElement("div");
    temporalDivElement.innerHTML = html;
    var imgurl=temporalDivElement.childNodes[0].src
    //console.log(imgurl)
    return !(imgurl.indexOf('default_profile_') !== -1) 
}
/* var properties_obj = { bio : true,
                       loc : true,
                       url  : true,
                       img  : true,
                       }; */

var shalluseoptions=false
function executefunction(myStr,functionname,value){
    switch (functionname) {
        case 'bio':
            return checkbio(myStr,value);
            break;
        case 'loc':
            return checklocation(myStr,value);
            break;
        case 'url':
            return checkurlText(myStr,value);
            break;
        case 'img':
            return checkimage(myStr);   
            break;
        case 'nonfollows':
            return checkwhetherfollowing(myStr);   
            break;            
    }
}

var properties_obj={}
var shalluseoptions,removeimagesvar
function getusersettings(username){
  // Use default value loc = 'red' and useoptions = true.
  chrome.storage.local.get({
    locunfollow: 'none',
    urlunfollow: 'none',
    biounfollow: 'none',
    imgunfollow: 'none',
    locunfollowinput: '',
    urlunfollowinput: '',
    biounfollowinput: '',     
    useoptionsunfollow: false,
    removeimagesunfollow:false,
    nonfollows: false,
	skipverified:false,
    followcount: 0,
    unfollowcount: 0,
    unfollowlimit :1000,
    followednames:'[]',
    skipyoungfollows:false
  }, function(items) {
    shalluseoptions=items.useoptionsunfollow;
    properties_obj = {     bio : [items.biounfollow,items.biounfollowinput],
                           loc : [items.locunfollow,items.locunfollowinput],
                           url : [items.urlunfollow,items.urlunfollowinput],
                           img : [items.imgunfollow,''],
                           nonfollows : [items.nonfollows,''],
                           };  
    unfollowcount_twitter=parseInt(items.unfollowcount);
    unfollowlimit_twitter=parseInt(items.unfollowlimit);
    followcount_twitter =parseInt(items.followcount);
    unfollowcount_sub=unfollowcount_twitter;
    removeimagesvar=items.removeimagesunfollow;
    nonfollowers=items.nonfollows;
	skipverified=items.skipverified;
    followednames=JSON.parse(items.followednames);
    excludearr=getyoungerthandays(followednames);
    skipyoungfollows=items.skipyoungfollows;
    setTimeout(function(){removeoldnames(followednames); }, 3000);
    //console.log(excludearr);
    //document.getElementById('tafunfollowed').textContent=unfollowcount_twitter;
    //document.getElementById('taffollowed').textContent=followcount_twitter;
    //return checkuser(username)
/*     console.log(properties_obj);
    console.log(shalluseoptions);  */
  });
}


var followednames=[];
var excludearr=[];
var skipyoungfollows=false;

function getrecentdates(num){
  var dates = [];
  var date = new Date();

  for (var i = 0; i < num; i++){
    var tempDate = new Date();
    tempDate.setDate(date.getDate()-i);
    var str = tempDate.getDate();
    dates.push(str);  
  }
 return dates;
}

function isInArray(value, array) {
  return array.indexOf(value) > -1;
}
function getyoungerthandays(array1){
    var excludearr=[];
    /* var tdate = new Date();
    var td1=tdate.getDate()
    tdate.setDate(tdate.getDate()-1);
    var td2=tdate.getDate()  
    tdate.setDate(tdate.getDate()-1);
    var td3=tdate.getDate()   */
	var recent_valid_dates=getrecentdates(3);
  for(var i = 0; i < array1.length; i++){
	  
      //if(td1==array1[i][1] || td2==array1[i][1] || td3==array1[i][1])
	  if(recent_valid_dates.includes(array1[i][1]))
			excludearr.push(array1[i][0])
      else
      {
          array1[i][0]='';
          array1[i][0]=0;
      }
  }

  return excludearr;
}

function removeoldnames(array1){
    var latestarr=[];
/*     var tdate = new Date();
    var td1=tdate.getDate()
    tdate.setDate(tdate.getDate()-1);
    var td2=tdate.getDate()  
    tdate.setDate(tdate.getDate()-1);
    var td3=tdate.getDate()  */
  var recent_valid_dates=getrecentdates(15);
  for(var i = 0; i < array1.length; i++){
      //if(td1==array1[i][1] || td2==array1[i][1] || td3==array1[i][1])
      if(recent_valid_dates.includes(array1[i][1]))
       		latestarr.push(array1[i])

        if(i==array1.length-1)
        {
            console.log('=============================')
            chrome.storage.local.set({followednames:JSON.stringify(latestarr)}, function() {});
            console.log('=============================')
        }
           
   // if(i==array1.length-1)
     //   chrome.storage.local.set({followednames:JSON.stringify(latestarr)}, function() {});
  }
  


}

function checkuser(username,button){
    var prop_arr=[]
    console.log(username)
    var isvalid=true;
    if(shalluseoptions==false)
        return true
    
    if(prev_screen_name!=username)
        prev_screen_name=username
    else
    {   
         console.log('prev_screen_name==username')
        button.remove()
        return true
        
    }
    var request = new XMLHttpRequest(); 
    request.open("GET", 'https://twitter.com/'+username);
    request.onreadystatechange = function() { 
        if (request.readyState === 4 && request.status === 200) {
                var myStr = request.responseText;
               Object.keys(properties_obj).forEach(function(key) {
                 console.log(key, properties_obj[key]);      
                  if(properties_obj[key][0]=='exist')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==true)
                  else if(properties_obj[key][0]=='notexist')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==false)
                  else if(properties_obj[key][0]=='contain')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==true)
                  else if(properties_obj[key][0]=='notcontain')
                    isvalid =(executefunction(myStr,key,properties_obj[key])==false)     
              //    else if(properties_obj[key][0]==true)
              //      isvalid =(executefunction(myStr,key,properties_obj[key])==false)
                  else
                  {
                    isvalid =true
                    }
                
                console.log(isvalid)
                if (isvalid==false)
                {
                    prop_arr.push(0)
                    
                }
                else 
                {
                   prop_arr.push(1)
                    
                }
                if (prop_arr.length==5 && !prop_arr.includes(0))
                { 
                    unfollowcount_twitter=unfollowcount_twitter+1;
                    saveunfollowcount(unfollowcount_twitter);
                    
                
                    
                    toast_twitter_follow("green",username)
                    console.log('this is valid');
					schedulecountmax();
					countmax();
                    button.click();
                }
                else if (prop_arr.length==5 && prop_arr.includes(0))    
                {  
                    toast_twitter_follow("red",username)
                    console.log('this is invalid'); 
                    button.remove()
            
            }
                    
                });
            
            
        }
    };
    request.send(null); 
}


//============================un follow=============================
var prev_screen_name=''
function hexColorDelta(hex1, hex2) {
    // get red/green/blue int values of hex1
    var r1 = parseInt(hex1.substring(0, 2), 16);
    var g1 = parseInt(hex1.substring(2, 4), 16);
    var b1 = parseInt(hex1.substring(4, 6), 16);
    // get red/green/blue int values of hex2
    var r2 = parseInt(hex2.substring(0, 2), 16);
    var g2 = parseInt(hex2.substring(2, 4), 16);
    var b2 = parseInt(hex2.substring(4, 6), 16);
    // calculate differences between reds, greens and blues
    var r = 255 - Math.abs(r1 - r2);
    var g = 255 - Math.abs(g1 - g2);
    var b = 255 - Math.abs(b1 - b2);
    // limit differences between 0 and 1
    r /= 255;
    g /= 255;
    b /= 255;
    // 0 means opposit colors, 1 means same colors
    return (r + g + b) / 3;
}

function componentToHex(c) {
    c=parseInt(c)
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
}

function rgbToHex(rgb) {
    rgb = rgb.substring(4, rgb.length-1)
         .replace(/ /g, '')
         .split(',');

    return "#" + componentToHex(rgb[0]) + componentToHex(rgb[1]) + componentToHex(rgb[2]);
}

function hasClass(element, cls) {
    return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
}
var firstrun=true
function autounfollow()
{ 
    if(firstrun)
    {
        firstrun=false
        removeimages();
    }
    scrolldowncount=scrolldowncount+1
    if(scrolldowncount%6==0){
        removeimages()
        window.scrollTo(0,document.body.scrollHeight);
    }
var count_follows=0
var buttons = document.querySelectorAll('button.unfollow-text')
for (var i = 0; i < buttons.length; i++) {
    var screenname=buttons[i].parentElement.parentElement.getAttribute('data-screen-name')
    console.log(screenname)
	console.log('isInArray(screenname, excludearr) && skipyoungfollows ==465')
	console.log(isInArray(screenname, excludearr) && skipyoungfollows)	
    if (isInArray(screenname, excludearr) && skipyoungfollows)
    {
        buttons[i].parentElement.remove();
        return autounfollow(interval, interval2);
    }
    var button = buttons[i];
    var textContent = button.textContent;	
    if (skipverified && (findUpTag(button,'js-actionable-user').querySelectorAll('.Icon--verified').length>0))
    {
        buttons[i].parentElement.remove();
        return autounfollow(interval, interval2);
    }	

    if(nonfollowers && checkfollower(button))
    {
        button.parentElement.remove();
        return autounfollow(interval, interval2);
    } 

        
    if (hasClass(button.parentElement.parentElement, 'following'))
    {
                     //console.log(textContent);
                     button.parentElement.parentElement.className.replace(/\bfollowing\b/g, "");
					 schedulecountmax();
					 countmax();
                     button.click();
                     count_follows = count_follows + 1;
                     
                 }

      

  
  if ((followrate <= count_follows) || (i == (buttons.length - 1)))
  {
                        unfollowcount_twitter=unfollowcount_twitter+count_follows;
                        saveunfollowcount(unfollowcount_twitter);
                        if(unfollowcount_twitter>=unfollowlimit_twitter)
                        {
                            saveunfollowcount(unfollowlimit_twitter);
                            alert('Unfollow limit exceeded for the day');
                            location.reload();
                            return;
                        }
                        else
                        {
                            
      return setTimeout(function() {autounfollow(interval, interval2)}, randomIntFromInterval(interval,interval2));      
                        }
  }
 // if (i == (buttons.length-1))
   //         return   setTimeout(function(){autounfollow()}, randomIntFromInterval(interval,interval2));//return   setTimeout(function(){autounfollow()}, unfollow_interval);
    
}
}

function autounfollow2()
{ 
try 
    {   

    if(firstrun)
    {
        firstrun=false
        removeimages();
    }
    scrolldowncount=scrolldowncount+1;
    if(scrolldowncount%4==0){    
        removeimages()
        window.scrollBy(0, document.body.scrollHeight / 25);
    }
    var buttons = document.querySelectorAll('button.unfollow-text')
    var button = buttons[0];
    var textContent = button.textContent;

    var screenname=button.parentElement.parentElement.getAttribute('data-screen-name')
	console.log('isInArray(screenname, excludearr) && skipyoungfollows ==540')
	console.log(isInArray(screenname, excludearr) && skipyoungfollows)
    if (isInArray(screenname, excludearr) && skipyoungfollows)
    {
        button.parentElement.remove();
        return autounfollow2();
    }

    if(unfollowcount_twitter>=unfollowlimit_twitter)
    {
        alert('Unfollow limit exceeded for the day');
        saveunfollowcount(unfollowlimit_twitter);
        location.reload();
        return;
    }    
    else{

    console.log('follows you');
   // console.log(checkfollower(button));

    if(nonfollowers && checkfollower(button))
    {
        
        button.parentElement.remove();
        return autounfollow2();
    }         

    if (hasClass(button.parentElement.parentElement, 'following'))
    {
                    //console.log(textContent);
                    //var screenname=button.parentElement.parentElement.getAttribute('data-screen-name');
                    console.log(screenname)

                    
                    
                    setTimeout(function(){ checkuser(screenname,button) }, 100);
                    setTimeout(function(){autounfollow2()}, randomIntFromInterval(interval,interval2));
    }
    else
    {
        button.remove()
        setTimeout(function(){autounfollow2()}, 500);
    }
}
      
      }catch(err) 
    {
        setTimeout(function(){autounfollow2()}, 500); 
    }
    
//}
}
function removeimages(){
    if(removeimagesvar)
    {
        var images = document.getElementsByTagName('img');
        var l = images.length;
        for (var i = 0; i < l; i++) {
            images[0].parentNode.removeChild(images[0]);
        }    
        var images2 = document.getElementsByClassName("ProfileCard-bg js-nav");
        var l = images2.length;
        for (var i = 0; i < l; i++) {
            images2[0].parentNode.removeChild(images2[0]);
        }   
    }    
}

var unfollow_interval=3000


var scrolldowncount=0
getusersettings()
setTimeout(function(){ 
console.log(shalluseoptions)
if(shalluseoptions)
{
    
    if(interval<3000)
        interval=interval+3000;
    if(interval2<3000)
        interval2=interval2+3000;
    unfollow_interval=interval
    autounfollow2();
}
else
{
    unfollow_interval=interval
    autounfollow();
}
 }, 1000);


function randomIntFromInterval(min, max) {
    var slptime=Math.floor(Math.random() * (max - min + 1) + min);
    console.log(slptime)
    return slptime;
}


function toast_twitter_follow(bgcolor,screenname){
    
        var options = {
        style: {
            main: {
                //background: "#ee6c6c",
                background: bgcolor,
                color: "black",
                'max-width': '30%',
                'border-radius': '8px',
            }
        },                            
        settings: {
            duration: 2500
        }
    };

    iqwerty.toast.Toast('@'+screenname, options);    
    
}
//alert(interval)
var unfollowcount_twitter,unfollowlimit_twitter
function saveunfollowcount(unfollowcount_twitter){
    
    chrome.storage.local.set({unfollowcount:unfollowcount_twitter}, function() {});
    document.getElementById('tafunfollowed').textContent=unfollowcount_twitter-unfollowcount_sub;
}
var unfollowcount_sub
addcountwidget()
function addcountwidget(){  
    var optionsUrl = chrome.extension.getURL("options.html"); 
    var optionstag = '<a href="' + optionsUrl + '" style="font-size: 20px;    color: #14171a;" target="_blank">Options</a>';
    var donationtag = '<a href="https://toolsfor.us/tutorials/index.html?app_name=Twitter_Auto_Follower" style="font-size: 20px;    color: #14171a;" target="_blank">Tips</a>';    
    var p_ele=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 10em;    right: 12em;border-radius: 15px 30px;    background: #3593a0;    padding: 20px;     width: 90px;    height: 65px;" class="rcorners"><table><tr><td align="center">Followed</td></tr><tr><td align="center"><span style="font-size: 35px;font-weight: bold;" id="taffollowed">0</span></td></tr></table></div>')
    var p_ele2=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 10em;    right: 1em;border-radius: 15px 30px;    background: #3593a0;    padding: 20px;     width: 90px;    height: 65px;" class="rcorners2"><table><tr><td align="center">Unfollowed</td></tr><tr><td align="center"><span style="font-size: 35px;font-weight: bold;"id="tafunfollowed">0</span></td></tr></table></div>')
    var p_ele3=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 24em;    right: 4.5em;border-radius: 15px 15px;    background: #3593a0;    padding: 20px;     width: 130px;    height: 20px;" >'+optionstag+'</div>');
    var p_ele4=createElement('<div align="center" style="z-index:2000;position: fixed;    top: 18em;    right: 7em;border-radius: 15px 15px;    background: #ff3a3a;    padding: 20px;     width: 60px;    height: 35px;" >'+donationtag+'</div>')
    document.getElementsByTagName("body")[0].appendChild(p_ele)
    document.getElementsByTagName("body")[0].appendChild(p_ele2)
    document.getElementsByTagName("body")[0].appendChild(p_ele3)
    document.getElementsByTagName("body")[0].appendChild(p_ele4)    
}
function createElement( str ) {
    var frag = document.createDocumentFragment();

    var elem = document.createElement('div');
    elem.innerHTML = str;

    while (elem.childNodes[0]) {
        frag.appendChild(elem.childNodes[0]);
    }
    return frag;
}


       
function checkfollower(ele)
{
    try{
//    console.log(ele.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement)
    if(ele.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.querySelector('span.FollowStatus').textContent!=null)
        return true
    else
        return false
    }
    catch(e)
    {
        
        return false
    }
}


var counter=0
var runonce=true
function countmax(){
	counter=counter+1;
	if(counter>procount)
	{
		if(runonce){
			runonce=false
			chrome.extension.sendMessage({ cmd: "alert" ,msg:'Please buy pro version and support us, It has lot more features'});
			chrome.extension.sendMessage({ cmd: "protab"});
		}
        location.reload();
	}
}


var schedulecounter=0
var schedulerunonce=true
function schedulecountmax(){
	try{
	console.log('schedulecountval=='+schlcntv)
	console.log('procount=='+procount)
	
	schedulecounter=schedulecounter+1;
/* 	if (typeof schlcntv === 'undefined') {
		var schlcntv=1000
	} */
	console.log(schedulecounter+' > '+schlcntv)
	if(schedulecounter>schlcntv)
	{
		window.close(); 
	}}
	catch(e){}
}