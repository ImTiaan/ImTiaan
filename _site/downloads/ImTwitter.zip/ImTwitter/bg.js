/* Check whether new version is installed */
chrome.runtime.onInstalled.addListener(function(details) {
    /* other 'reason's include 'update' */
    if (details.reason == "install") {
        /* If first install, set uninstall URL */
        var uninstallGoogleFormLink = 'https://goo.gl/g54jMN';

		
        /* If Chrome version supports it... */
        if (chrome.runtime.setUninstallURL) {
            chrome.runtime.setUninstallURL(uninstallGoogleFormLink);
        }
		 chrome.windows.create({url: "https://toolsfor.us/tutorials/index.html?app_name=Twitter_Auto_Follower",incognito: true},function(w) {});
    }
});

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse){
        if(request.cmd == "alert") alert(request.msg);
		if(request.cmd == "protab") chrome.tabs.create({ url: 'https://chrome.google.com/webstore/detail/twitter-auto-follower-pro/igjpgjieplfmhjmgcpjeocjkbchaddli' });
		if(request.cmd == "tutorial") chrome.windows.create({url: "https://toolsfor.us/tutorials/index.html?app_name=Twitter_Auto_Follower",incognito: true},function(w) {});
    }
);





function getlatestschedule(){
chrome.storage.local.get({tableobj:'none'}, function(result) {
	var table=result.tableobj
	if(table!='none')
	{
		   for(var row in table){
				   if(!table[row].schcheckbox)
				   {
					   var istime=ShowLocalDate(table[row].hr,table[row].mins)
					    console.log(table[row].hr)
						console.log(istime)
						if (istime)
						{
							table[row].schcheckbox=true
							callfunction(table[row],table)
							break;
						}
				   }
		   }
	}
	
});	
}

function callfunction(obj,tableobj){
chrome.storage.local.set({tableobj: tableobj}, function() {});	
var duration = obj.min;
var duration2 = obj.max;

var time_type = obj.time_type;
var interval='var interval='+converttomilli(duration,time_type)+';';    
var interval2='var interval2='+converttomilli(duration2,time_type)+';';  
var followrate='var followrate='+obj.rate+';';
if(parseInt(obj.schedulecount)>15)
	obj.schedulecount=15
var schedulecountstr='var schlcntv='+obj.schedulecount+';';

var procount=' var procount=50;'
var closewindow=' setTimeout(function(){ window.close() }, 500000);';
var execode= interval+interval2+followrate+procount+schedulecountstr+closewindow;
//alert(execode)
 	try{	
	chrome.tabs.create({url: obj.url, active: false},function(tab,info){
  setTimeout(function(){{
        chrome.tabs.executeScript(tab.id,{file: 'toast.js'});
          chrome.tabs.executeScript(tab.id,{code: execode}); 	
			chrome.tabs.executeScript(tab.id,{file: obj.schedule_type + '.js'});	
		}  }, 5000);
	
	});

		}
		catch(e){alert(e)}  


}



function runinbg(){
	console.log('running scheduler')
	try{getlatestschedule()}catch(e){}
	setTimeout(function(){ runinbg(); }, 600000);
}

function ShowLocalDate(h,m){
    var dNow = new Date();
    var localdate= new Date();
	var scheduleddate=new Date(dNow.getFullYear(), dNow.getMonth(), dNow.getDate(), h, m, 0);
	
	console.log(localdate)
	console.log(scheduleddate)
	return(localdate>scheduleddate);
    
}
function converttomilli(dur,type)
{
    if (type=='sec')
        dur=dur*1000
    else if (type=='min')
        dur=dur*60*1000
    else if (type=='hr')
        dur=dur*60*60*1000
    else if (type=='day')
        dur=dur*24*60*60*1000    
    
    return dur;
    
}
      

setdatecount_schedule()		
function setdatecount_schedule(){
var today = new Date();
var dd = today.getDate(); 
chrome.storage.local.get('twitter_follower_date_schedule', function(data) {
if (typeof data.twitter_follower_date_schedule === 'undefined' || data.twitter_follower_date_schedule!=dd ) {
             chrome.storage.local.set({
                    twitter_follower_date_schedule: dd
                }, function() {
					
				 chrome.storage.local.get({tableobj:'none',scheduleeveryday:false}, function(result) {
					 if(result.scheduleeveryday)
					 {
						 for (const key of Object.keys(result.tableobj)) {
								//console.log(key, result.tableobj[key]);
								result.tableobj[key].schcheckbox=false;
							}
							chrome.storage.local.set({tableobj: result.tableobj}, function() {setTimeout(function(){ runinbg(); }, 300000);});
					 }
					 else
						 setTimeout(function(){ runinbg(); }, 300000);
						});
											
					
				});                
        }
		else
			setTimeout(function(){ runinbg(); }, 300000);
        });
    
}
			  

